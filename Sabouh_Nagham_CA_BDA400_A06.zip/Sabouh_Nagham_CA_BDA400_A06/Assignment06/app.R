# BDA400 Assignment 6 | Nagham Sabouh | Portfolio Visualization Dashboard
# Launch from this directory using shiny::runApp('.')
# Requires an internet connection for Yahoo Finance.
required <- c('shiny', 'ggplot2', 'quantmod', 'TTR', 'xts')
missing <- required[!vapply(required, requireNamespace, logical(1), quietly = TRUE)]
if (length(missing)) stop('Install packages first: ', paste(missing, collapse = ', '))
library(shiny)
library(ggplot2)

# Yahoo Finance data retrieval with recoverable user-facing errors.
fetch_prices <- function(symbol, start, end, timeframe) {
  x <- quantmod::getSymbols(symbol, src = 'yahoo', from = start, to = end + 1,
                            auto.assign = FALSE, warnings = FALSE)
  if (NROW(x) == 0L) stop('No prices found for that symbol/date range.')
  if (timeframe == 'Weekly') x <- xts::to.weekly(x, indexAt = 'endof', OHLC = TRUE)
  if (timeframe == 'Monthly') x <- xts::to.monthly(x, indexAt = 'endof', OHLC = TRUE)
  # Use column position rather than fragile names after aggregation.
  # xts aggregation may change OHLC name conventions.
  vals <- data.frame(Date = as.Date(zoo::index(x)),
                     Open = as.numeric(quantmod::Op(x)),
                     High = as.numeric(quantmod::Hi(x)),
                     Low = as.numeric(quantmod::Lo(x)),
                     Close = as.numeric(quantmod::Cl(x)),
                     Volume = as.numeric(quantmod::Vo(x)))
  vals <- vals[stats::complete.cases(vals[, c('Date','Open','High','Low','Close')]), ]
  if (!nrow(vals)) stop('No usable OHLC prices returned.')
  vals
}

# All indicators are computed after time-frame aggregation.
add_indicators <- function(d, short_n = 10L, long_n = 30L) {
  if (short_n >= long_n) stop('Short MA period must be less than long MA period.')
  d$ShortMA <- as.numeric(TTR::SMA(d$Close, n = short_n))
  d$LongMA <- as.numeric(TTR::SMA(d$Close, n = long_n))
  d$RSI <- as.numeric(TTR::RSI(d$Close, n = 14))
  m <- TTR::MACD(d$Close, nFast = 12, nSlow = 26, nSig = 9, maType = 'EMA', percent = FALSE)
  d$MACD <- as.numeric(m[, 1]); d$SignalLine <- as.numeric(m[, 2])
  d$Histogram <- d$MACD - d$SignalLine
  # True crossing event, not persistent short > long state.
  prev_s <- c(NA_real_, head(d$ShortMA, -1L))
  prev_l <- c(NA_real_, head(d$LongMA, -1L))
  d$TradeSignal <- 'Hold'
  buy <- !is.na(d$ShortMA) & !is.na(d$LongMA) & !is.na(prev_s) & !is.na(prev_l) &
    d$ShortMA > d$LongMA & prev_s <= prev_l
  sell <- !is.na(d$ShortMA) & !is.na(d$LongMA) & !is.na(prev_s) & !is.na(prev_l) &
    d$ShortMA < d$LongMA & prev_s >= prev_l
  d$TradeSignal[buy] <- 'Buy'; d$TradeSignal[sell] <- 'Sell'
  d
}

ui <- fluidPage(
  titlePanel('BDA400 | Interactive Stock Portfolio Dashboard'),
  sidebarLayout(
    sidebarPanel(width = 3,
      selectInput('symbol', 'Stock symbol', c('AAPL', 'MSFT', 'GOOG', 'AMZN', 'TSLA')),
      textInput('custom_symbol', 'Or enter a ticker (optional)', ''),
      dateRangeInput('dates', 'Date range', start = Sys.Date() - 730, end = Sys.Date(), max = Sys.Date()),
      selectInput('timeframe', 'Time frame', c('Daily', 'Weekly', 'Monthly')),
      selectInput('chart', 'Price chart', c('Line', 'Area', 'Candlestick')),
      checkboxGroupInput('indicators', 'Show indicators',
        choices = c('Moving Averages', 'RSI', 'MACD'), selected = 'Moving Averages'),
      numericInput('short_n', 'Short moving average period', 10, min = 2, max = 100),
      numericInput('long_n', 'Long moving average period', 30, min = 3, max = 250),
      checkboxInput('annotations', 'Annotate Buy / Sell events', TRUE),
      actionButton('refresh', 'Fetch / refresh data'),
      helpText('Signals are demonstrations, not investment advice. Yahoo Finance data requires internet access.')
    ),
    mainPanel(width = 9,
      textOutput('status'),
      plotOutput('price_plot', height = '410px'),
      conditionalPanel("input.indicators.indexOf('RSI') >= 0", plotOutput('rsi_plot', height = '210px')),
      conditionalPanel("input.indicators.indexOf('MACD') >= 0", plotOutput('macd_plot', height = '240px')),
      h4('Latest analysis and trading signals'), tableOutput('latest'),
      h4('Most recent Buy / Sell events'), tableOutput('signals'),
      downloadButton('download', 'Download analyzed CSV')
    )
  )
)

server <- function(input, output, session) {
  data <- eventReactive(input$refresh, {
    ticker <- trimws(toupper(if (nzchar(trimws(input$custom_symbol))) input$custom_symbol else input$symbol))
    validate(need(grepl('^[A-Z0-9.^-]{1,15}$', ticker), 'Enter a valid stock symbol.'))
    validate(need(!is.null(input$dates) && input$dates[1] < input$dates[2], 'Choose a valid date range.'))
    validate(need(input$short_n < input$long_n, 'Short MA must be smaller than long MA.'))
    tryCatch(add_indicators(fetch_prices(ticker, input$dates[1], input$dates[2], input$timeframe),
                             as.integer(input$short_n), as.integer(input$long_n)),
             error = function(e) validate(need(FALSE, paste('Download/analysis error:', conditionMessage(e)))))
  }, ignoreNULL = FALSE)

  output$status <- renderText({ d <- data(); paste(nrow(d), 'observations |', min(d$Date), 'to', max(d$Date),
                                                  '| Latest signal:', tail(d$TradeSignal, 1)) })
  output$price_plot <- renderPlot({
    d <- data()
    p <- ggplot(d, aes(x = Date)) + labs(title = 'Stock price and trading events', x = 'Date', y = 'Price (USD)') + theme_minimal()
    if (input$chart == 'Line') p <- p + geom_line(aes(y = Close), color = '#2563eb', linewidth = 0.7)
    if (input$chart == 'Area') p <- p + geom_area(aes(y = Close), fill = '#93c5fd', alpha = 0.6) + geom_line(aes(y = Close), color = '#1d4ed8')
    if (input$chart == 'Candlestick') {
      d$Up <- d$Close >= d$Open
      p <- p + geom_linerange(data = d, aes(ymin = Low, ymax = High), color = 'gray45') +
        geom_rect(data = d, aes(xmin = Date - 0.35, xmax = Date + 0.35,
                               ymin = pmin(Open, Close), ymax = pmax(Open, Close), fill = Up),
                  color = 'gray40', linewidth = 0.2) +
        scale_fill_manual(values = c('TRUE' = '#16a34a', 'FALSE' = '#dc2626'), guide = 'none')
    }
    if ('Moving Averages' %in% input$indicators) p <- p +
      geom_line(aes(y = ShortMA, color = 'Short MA'), linewidth = 0.7, na.rm = TRUE) +
      geom_line(aes(y = LongMA, color = 'Long MA'), linewidth = 0.7, na.rm = TRUE) +
      scale_color_manual(values = c('Short MA' = '#f97316', 'Long MA' = '#7c3aed'), name = 'Overlay')
    if (input$annotations) {
      events <- subset(d, TradeSignal != 'Hold')
      p <- p + geom_point(data = events, aes(y = Close, shape = TradeSignal), size = 3, color = '#111827') +
        geom_text(data = events, aes(y = Close, label = TradeSignal), vjust = -1, size = 3, check_overlap = TRUE)
    }
    print(p)
  })
  output$rsi_plot <- renderPlot({
    d <- data(); ggplot(d, aes(Date, RSI)) + geom_line(color = '#7c3aed', na.rm = TRUE) +
      geom_hline(yintercept = c(30, 70), linetype = 'dashed', color = 'gray50') +
      coord_cartesian(ylim = c(0, 100)) + labs(title = 'RSI (14)', x = 'Date', y = 'RSI') + theme_minimal()
  })
  output$macd_plot <- renderPlot({
    d <- data(); ggplot(d, aes(Date)) + geom_col(aes(y = Histogram), fill = 'gray65', na.rm = TRUE) +
      geom_line(aes(y = MACD, color = 'MACD'), linewidth = 0.8, na.rm = TRUE) +
      geom_line(aes(y = SignalLine, color = 'Signal'), linewidth = 0.8, na.rm = TRUE) +
      scale_color_manual(values = c(MACD = '#2563eb', Signal = '#f97316'), name = NULL) +
      labs(title = 'MACD (12, 26, 9)', x = 'Date', y = 'MACD') + theme_minimal()
  })
  output$latest <- renderTable({
    d <- tail(data(), 1)
    transform(d[, c('Date','Close','ShortMA','LongMA','RSI','MACD','SignalLine','TradeSignal')],
              Close = round(Close, 2), ShortMA = round(ShortMA, 2), LongMA = round(LongMA, 2),
              RSI = round(RSI, 2), MACD = round(MACD, 2), SignalLine = round(SignalLine, 2))
  })
  output$signals <- renderTable({
    d <- subset(data(), TradeSignal != 'Hold')
    tail(d[, c('Date', 'Close', 'TradeSignal'), drop = FALSE], 10)
  })
  output$download <- downloadHandler(filename = function() paste0('BDA400_', Sys.Date(), '_analysis.csv'),
                                      content = function(file) write.csv(data(), file, row.names = FALSE))
}
shinyApp(ui, server)

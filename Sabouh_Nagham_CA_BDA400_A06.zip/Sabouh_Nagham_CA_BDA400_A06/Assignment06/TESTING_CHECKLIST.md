# Testing record (complete in RStudio)

- [ ] R and RStudio installed, packages installed using `install_packages.R`.
- [ ] `app.R` launches without errors.
- [ ] AAPL or MSFT data loads for a multi-year date range.
- [ ] Daily, Weekly, Monthly frequencies work.
- [ ] Line, Area, and Candlestick chart types display correctly.
- [ ] Moving Average checkbox toggles both MA lines.
- [ ] RSI checkbox toggles RSI plot (0–100, levels 30 and 70).
- [ ] MACD checkbox toggles MACD, signal line and histogram.
- [ ] Short/long MA period settings affect Buy/Sell signals.
- [ ] On/off signal annotations work and Buy/Sell events are distinct from Hold.
- [ ] Invalid ticker and short >= long produce visible validation messages.
- [ ] CSV download contains OHLC, indicators, and trading signals.
- [ ] Genuine screenshots taken and GitHub URL verified.

**Testing notes:** Record date, R version, test symbol, result, and any fixes here.

# BDA400 Assignment 6 — Portfolio Visualization Phase

**Student:** Nagham Sabouh  
**Course:** BDA400 Data Science Tools and Techniques

## Features
- Live Yahoo Finance historical OHLC stock prices using `quantmod`.
- Adjustable symbol, date range, and daily / weekly / monthly frequency.
- Line, area, and candlestick views.
- Toggleable moving average overlay and separate RSI and MACD panels.
- Configurable short and long MA crossover rules, Buy/Sell event markers and Hold state.
- Recent signals, last observation, and CSV export.

RSI and MACD have different scales than price, so they appear in separately labelled panels instead of being overlaid on the price y-axis. The instructor's `geom_ma`, `geom_rsi`, and `geom_macd` examples are conceptual placeholders, not standard ggplot2 functions; this application draws the layers directly.

## Run
1. Install R and RStudio.
2. Open RStudio and set the working directory to `Assignment06`.
3. Run `source('install_packages.R')` once.
4. Run `shiny::runApp('.')` or open `app.R` and choose **Run App**.
5. Choose stock, dates and time-frame, then click **Fetch / refresh data**.

Yahoo downloads need internet; missing tickers or provider outages will produce a notification rather than a fabricated plot. At least 30 aggregated bars are preferable for the longer moving average; 35+ for MACD.

## Trading rule
**Buy** when the short MA crosses from at/below to above the long MA. **Sell** when it crosses from at/above to below. All other bars are **Hold**. Signals are historical educational demonstrations and do not predict returns.

## Verification
Run RStudio locally, verify a valid stock for each frequency and chart type, toggle indicators, adjust MA periods, confirm signal labels and download output. Capture authentic screenshots. No successful RStudio run is claimed in this package.

## Submission
Upload the project files to a **public** GitHub repository. Insert its verified URL into the Word cover page and submit the cover page in the LMS.

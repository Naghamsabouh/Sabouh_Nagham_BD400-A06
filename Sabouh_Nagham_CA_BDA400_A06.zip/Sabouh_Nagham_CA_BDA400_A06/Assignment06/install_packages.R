packages <- c('shiny','ggplot2','quantmod','TTR','xts','zoo')
new <- packages[!vapply(packages, requireNamespace, logical(1), quietly = TRUE)]
if (length(new)) install.packages(new, repos = 'https://cloud.r-project.org')
cat('Packages installed or already present.\n')
